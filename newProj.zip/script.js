function readTextFile(file, callback) {
    var rawFile = new XMLHttpRequest();
    rawFile.overrideMimeType("application/json");
    rawFile.open("GET", file, true);
    rawFile.onreadystatechange = function() {
        if (rawFile.readyState === 4 && rawFile.status == "200") {
            callback(rawFile.responseText);
        }
    }
    rawFile.send(null);
}

//usage:
readTextFile("json/movies.json", function(text){
    var data = JSON.parse(text);
	for(i=0;i<data.length;i++){
    console.log(data[i].title);
	
		var img = document.createElement("IMG");
		img.src="img/posters"+data[i].poster_path;
		
		var title = document.createElement("H3");
		var t = document.createTextNode(data[i].title);
		title.appendChild(t);
		
		document.getElementById("myDIV").appendChild(img);
		document.getElementById("myDIV").appendChild(title);

	}
});