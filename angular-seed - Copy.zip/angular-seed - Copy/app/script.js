var app = angular.module('movieApp', []);


app.controller('movieController', function($scope,$http) {
		$http.get('json/movies.json')
		.then(function(res){
		$scope.movies = res.data;
	});
					
	$scope.clickFunc = function() {
		$http.get("welcome.html")
		.then(function(response) {
			$scope.desc = response.data;
		});
	};
				
});

/*
app.config(['$routeProvider', function($routeProvider) {
   $routeProvider.when('/movieDetails', {
      templateUrl: 'movieDetails.html', controller: 'movieController'
   });
	
}]);*/

