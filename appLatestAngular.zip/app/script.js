var app = angular.module('movieApp', ["ngRoute"]);


app.controller('movieController', function($scope,$http) {
		$http.get('json/movies.json')
		.then(function(res){
		$scope.movies = res.data;
	});
					
	/*$scope.clickFunc = function() {
		$http.get("welcome.html")
		.then(function(response) {
			$scope.desc = response.data;
		});
	};*/
				
});


app.config(function($routeProvider) {
   $routeProvider.when('/movieDetails', {
      templateUrl: 'movieDetails.html', controller: 'movieDetailsController'
   });
	
});

app.controller("movieDetailsController", function ($scope) {
    $scope.message = "This is movie details section";
});

